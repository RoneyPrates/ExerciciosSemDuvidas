package com.mycompany.bicicleta;

public class CadastroBicicletas {
    public static void main(String[] args) {
        
        Bicicleta bike1 = new Bicicleta("Caloi", 26);
        bike1.cadastrarModelo("Explorer");
        bike1.cadastrarNumMarchas(18);
        bike1.preco = 1500.0;
        bike1.exibirBicicleta();
      
        Bicicleta bike2 = new Bicicleta("Specialized", 29);
        bike2.cadastrarModelo("Rockhopper");
        bike2.cadastrarNumMarchas(21);
        bike2.preco = 3500.0;
        bike2.exibirBicicleta();
      
        Bicicleta bike3 = new Bicicleta("Cannondale", 27);
        bike3.cadastrarModelo("Trail");
        bike3.cadastrarNumMarchas(24);
        bike3.preco = 2500.0;
      
        Bicicleta bike4 = new Bicicleta("Trek", 26);
        bike4.cadastrarModelo("Marlin");
        bike4.cadastrarNumMarchas(21);
        bike4.preco = 2000.0;
      
        // Mostrar 4 Mensagens destacando os 7 atributos das 2 primeiras bicicletas cadastradas
        System.out.println("\nPrimeira bicicleta cadastrada:");
        System.out.println("Marca: " + bike1.marca);
        System.out.println("Modelo: " + bike1.modelo);
        System.out.println("Número de Marchas: " + bike1.numMarchas);
        System.out.println("Cor: " + bike1.cor);
        System.out.println("Elétrica: " + bike1.eletrica);
        System.out.println("Aro: " + bike1.aro);
        System.out.println("Preço: " + bike1.preco);
      
        System.out.println("\nSegunda bicicleta cadastrada:");
        System.out.println("Marca: " + bike2.marca);
        System.out.println("Modelo: " + bike1.modelo);
        System.out.println("Número de Marchas: " + bike1.numMarchas);
        System.out.println("Cor: " + bike1.cor);
        System.out.println("Elétrica: " + bike1.eletrica);
        System.out.println("Aro: " + bike1.aro);
        System.out.println("Preço: " + bike1.preco);
        
        System.out.println("\nPrimeira bicicleta cadastrada:");
        System.out.println("Marca: " + bike1.marca);
        System.out.println("Modelo: " + bike1.modelo);
        System.out.println("Número de Marchas: " + bike1.numMarchas);
        System.out.println("Cor: " + bike1.cor);
        System.out.println("Elétrica: " + bike1.eletrica);
        System.out.println("Aro: " + bike1.aro);
        System.out.println("Preço: " + bike1.preco);
        
        System.out.println("\nPrimeira bicicleta cadastrada:");
        System.out.println("Marca: " + bike1.marca);
        System.out.println("Modelo: " + bike1.modelo);
        System.out.println("Número de Marchas: " + bike1.numMarchas);
        System.out.println("Cor: " + bike1.cor);
        System.out.println("Elétrica: " + bike1.eletrica);
        System.out.println("Aro: " + bike1.aro);
        System.out.println("Preço: " + bike1.preco);
    }
}
