package com.mycompany.bicicleta;

public class Bicicleta {

    public String marca;
    public int aro;
    public double preco;
  

    String modelo;
    int numMarchas;
    String cor;
    boolean eletrica;
  

    public void cadastrarModelo(String modelo) {
        this.modelo = modelo;
    }
  
    public void cadastrarNumMarchas(int numMarchas) {
        this.numMarchas = numMarchas;
    }
  
    
    public Bicicleta(String marca, int aro) {
        this.marca = marca;
        this.aro = aro;
    }
  
    
    public void exibirBicicleta() {
        System.out.println("Marca: " + marca);
        System.out.println("Aro: " + aro);
        System.out.println("Preço: " + preco);
        System.out.println("Modelo: " + modelo);
        System.out.println("Número de Marchas: " + numMarchas);
        System.out.println("Cor: " + cor);
        System.out.println("Elétrica: " + eletrica);
    }
}



